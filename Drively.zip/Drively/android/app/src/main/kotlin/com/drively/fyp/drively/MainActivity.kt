package com.drively.fyp.drively

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
